from django.contrib import admin

from .models import User, Customer

class AdminUser(admin.ModelAdmin):
    list_display = ['first_name','last_name','email','mobile']

class AdminCustomer(admin.ModelAdmin):
    list_display = ['profile_number']

admin.site.register(User,AdminUser)
admin.site.register(Customer,AdminCustomer)