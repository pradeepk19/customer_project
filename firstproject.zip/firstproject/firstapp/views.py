from django.shortcuts import render
from firstapp.models import User
from firstapp.serializers import UserSerializer

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

class UserListView(APIView):
    def get(self,request): # db --->> qs ---->> dict ---->> json ---->> browser
        user_list = User.objects.all() # []  | [{},{},{},...]

        serializer = UserSerializer(user_list,many=True) # dict

        return Response(serializer.data, status=status.HTTP_200_OK)


    def post(self,request): # browser ---->> json----->> dict---->>qs --->> db
        serilaizer = UserSerializer(data=request.data)
        if serilaizer.is_valid():
            serilaizer.save()
            return Response(serilaizer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(serilaizer.errors, status=status.HTTP_400_BAD_REQUEST)



class UserDetailView(APIView):
    def get(self,request,pk):
        try:
            user = User.objects.get(id=pk)
        except User.DoesNotExist:
            data = {"message" : "Requested resource not available"}
            return Response(data, status=status.HTTP_404_NOT_FOUND)
        else:
            serializer = UserSerializer(user)
            return Response(serializer.data, status=status.HTTP_200_OK)


    def get_object_by_id(self,pk):
        try:
            user = User.objects.get(id=pk)
        except:
            user = None
        return user
